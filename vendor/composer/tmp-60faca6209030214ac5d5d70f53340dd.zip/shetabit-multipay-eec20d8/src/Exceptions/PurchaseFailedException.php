<?php

namespace Shetabit\Multipay\Exceptions;

use Exception;

class PurchaseFailedException extends Exception
{
    //
}
