<?php

namespace Shetabit\Multipay\Exceptions;

class DriverNotFoundException extends \Exception
{
    //
}
